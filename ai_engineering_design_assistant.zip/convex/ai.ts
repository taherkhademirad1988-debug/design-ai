import { v } from "convex/values";
import { action, mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const generateEngineeringAdvice = action({
  args: {
    projectId: v.id("projects"),
    query: v.string(),
    category: v.union(
      v.literal("cad_assistance"), 
      v.literal("3d_modeling"), 
      v.literal("rendering_optimization"), 
      v.literal("structural_analysis"),
      v.literal("material_selection"),
      v.literal("code_generation")
    ),
  },
  handler: async (ctx, args): Promise<string> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    // Get project context
    const project: any[] = await ctx.runQuery(api.projects.getUserProjects, {});
    const currentProject: any = project.find((p: any) => p._id === args.projectId);
    
    if (!currentProject) {
      throw new Error("Project not found");
    }

    const systemPrompts = {
      cad_assistance: "You are an expert CAD engineer specializing in AutoCAD, SolidWorks, and Fusion 360. Provide detailed technical guidance for 2D and 3D CAD work.",
      "3d_modeling": "You are a 3D modeling expert proficient in Blender, Maya, 3ds Max, and engineering CAD software. Help with modeling techniques, topology, and workflows.",
      rendering_optimization: "You are a rendering specialist expert in V-Ray, Arnold, Cycles, and real-time engines. Provide optimization tips and quality improvements.",
      structural_analysis: "You are a structural engineer expert in FEA, load analysis, and building codes. Provide engineering calculations and safety recommendations.",
      material_selection: "You are a materials engineer. Help select appropriate materials for engineering applications considering strength, cost, and environmental factors.",
      code_generation: "You are a programming expert for engineering software. Generate scripts, macros, and automation code for CAD and engineering applications."
    };

    const prompt: string = `${systemPrompts[args.category]}

Project Context:
- Name: ${currentProject.name}
- Type: ${currentProject.type}
- Description: ${currentProject.description}
- Status: ${currentProject.status}

User Query: ${args.query}

Provide a detailed, technical response with specific recommendations, code examples if applicable, and best practices. Be practical and actionable.`;

    try {
      const response: any = await fetch(`${process.env.CONVEX_OPENAI_BASE_URL}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.CONVEX_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompts[args.category] },
            { role: "user", content: prompt }
          ],
          max_tokens: 1500,
          temperature: 0.7,
        }),
      });

      const data: any = await response.json();
      const aiResponse: string = data.choices[0].message.content;

      // Save the consultation
      await ctx.runMutation(api.ai.saveConsultation, {
        projectId: args.projectId,
        query: args.query,
        response: aiResponse,
        category: args.category,
      });

      return aiResponse;
    } catch (error) {
      console.error("AI API Error:", error);
      throw new Error("Failed to generate AI response");
    }
  },
});

export const saveConsultation = mutation({
  args: {
    projectId: v.id("projects"),
    query: v.string(),
    response: v.string(),
    category: v.union(
      v.literal("cad_assistance"), 
      v.literal("3d_modeling"), 
      v.literal("rendering_optimization"), 
      v.literal("structural_analysis"),
      v.literal("material_selection"),
      v.literal("code_generation")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    return await ctx.db.insert("aiConsultations", {
      projectId: args.projectId,
      userId,
      query: args.query,
      response: args.response,
      category: args.category,
    });
  },
});

export const getProjectConsultations = query({
  args: {
    projectId: v.id("projects"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("aiConsultations")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .collect();
  },
});

export const generateCode = action({
  args: {
    language: v.string(),
    description: v.string(),
    category: v.union(
      v.literal("autocad_lisp"), 
      v.literal("solidworks_macro"), 
      v.literal("blender_script"), 
      v.literal("revit_family"),
      v.literal("structural_calc")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    const codePrompts = {
      autocad_lisp: "Generate AutoCAD LISP code that is efficient and follows best practices. Include comments explaining the functionality.",
      solidworks_macro: "Generate SolidWorks VBA macro code with proper error handling and user interface elements where appropriate.",
      blender_script: "Generate Blender Python script using the bpy module. Include proper imports and error handling.",
      revit_family: "Generate Revit family creation code or Dynamo script for parametric modeling.",
      structural_calc: "Generate structural engineering calculation code with proper formulas and safety factors."
    };

    const prompt = `${codePrompts[args.category]}

Task: ${args.description}
Language: ${args.language}

Generate clean, well-documented code with:
1. Proper variable naming
2. Error handling
3. Comments explaining key sections
4. Best practices for the platform
5. Example usage if applicable`;

    try {
      const response = await fetch(`${process.env.CONVEX_OPENAI_BASE_URL}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.CONVEX_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: "You are an expert programmer for engineering software. Generate clean, efficient, and well-documented code." },
            { role: "user", content: prompt }
          ],
          max_tokens: 2000,
          temperature: 0.3,
        }),
      });

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error("Code generation error:", error);
      throw new Error("Failed to generate code");
    }
  },
});
