import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  projects: defineTable({
    name: v.string(),
    description: v.string(),
    type: v.union(v.literal("2d_cad"), v.literal("3d_modeling"), v.literal("rendering"), v.literal("structural")),
    status: v.union(v.literal("planning"), v.literal("in_progress"), v.literal("review"), v.literal("completed")),
    userId: v.id("users"),
    files: v.optional(v.array(v.id("_storage"))),
    aiSuggestions: v.optional(v.array(v.string())),
    tags: v.optional(v.array(v.string())),
  })
    .index("by_user", ["userId"])
    .index("by_type", ["type"])
    .index("by_status", ["status"]),

  aiConsultations: defineTable({
    projectId: v.id("projects"),
    userId: v.id("users"),
    query: v.string(),
    response: v.string(),
    category: v.union(
      v.literal("cad_assistance"), 
      v.literal("3d_modeling"), 
      v.literal("rendering_optimization"), 
      v.literal("structural_analysis"),
      v.literal("material_selection"),
      v.literal("code_generation")
    ),
    rating: v.optional(v.number()),
  })
    .index("by_project", ["projectId"])
    .index("by_user", ["userId"])
    .index("by_category", ["category"]),

  engineeringTemplates: defineTable({
    name: v.string(),
    description: v.string(),
    category: v.union(
      v.literal("autocad_lisp"), 
      v.literal("solidworks_macro"), 
      v.literal("blender_script"), 
      v.literal("revit_family"),
      v.literal("structural_calc")
    ),
    code: v.string(),
    language: v.string(),
    tags: v.array(v.string()),
    userId: v.id("users"),
    isPublic: v.boolean(),
  })
    .index("by_category", ["category"])
    .index("by_user", ["userId"])
    .index("by_public", ["isPublic"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
