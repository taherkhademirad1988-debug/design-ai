import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createProject = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    type: v.union(v.literal("2d_cad"), v.literal("3d_modeling"), v.literal("rendering"), v.literal("structural")),
    tags: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to create project");
    }

    return await ctx.db.insert("projects", {
      name: args.name,
      description: args.description,
      type: args.type,
      status: "planning",
      userId,
      tags: args.tags || [],
    });
  },
});

export const getUserProjects = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("projects")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const updateProjectStatus = mutation({
  args: {
    projectId: v.id("projects"),
    status: v.union(v.literal("planning"), v.literal("in_progress"), v.literal("review"), v.literal("completed")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    const project = await ctx.db.get(args.projectId);
    if (!project || project.userId !== userId) {
      throw new Error("Project not found or access denied");
    }

    await ctx.db.patch(args.projectId, {
      status: args.status,
    });
  },
});

export const addAiSuggestion = mutation({
  args: {
    projectId: v.id("projects"),
    suggestion: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    const project = await ctx.db.get(args.projectId);
    if (!project || project.userId !== userId) {
      throw new Error("Project not found or access denied");
    }

    const currentSuggestions = project.aiSuggestions || [];
    await ctx.db.patch(args.projectId, {
      aiSuggestions: [...currentSuggestions, args.suggestion],
    });
  },
});
