import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createTemplate = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    category: v.union(
      v.literal("autocad_lisp"), 
      v.literal("solidworks_macro"), 
      v.literal("blender_script"), 
      v.literal("revit_family"),
      v.literal("structural_calc")
    ),
    code: v.string(),
    language: v.string(),
    tags: v.array(v.string()),
    isPublic: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    return await ctx.db.insert("engineeringTemplates", {
      name: args.name,
      description: args.description,
      category: args.category,
      code: args.code,
      language: args.language,
      tags: args.tags,
      userId,
      isPublic: args.isPublic,
    });
  },
});

export const getPublicTemplates = query({
  args: {
    category: v.optional(v.union(
      v.literal("autocad_lisp"), 
      v.literal("solidworks_macro"), 
      v.literal("blender_script"), 
      v.literal("revit_family"),
      v.literal("structural_calc")
    )),
  },
  handler: async (ctx, args) => {
    if (args.category) {
      return await ctx.db.query("engineeringTemplates")
        .withIndex("by_category", (q) => q.eq("category", args.category!))
        .filter((q) => q.eq(q.field("isPublic"), true))
        .order("desc")
        .collect();
    }
    
    return await ctx.db.query("engineeringTemplates")
      .withIndex("by_public", (q) => q.eq("isPublic", true))
      .order("desc")
      .collect();
  },
});

export const getUserTemplates = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("engineeringTemplates")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});
