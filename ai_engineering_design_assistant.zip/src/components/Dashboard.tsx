import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ProjectManager } from "./ProjectManager";
import { AIConsultant } from "./AIConsultant";
import { CodeGenerator } from "./CodeGenerator";
import { TemplateLibrary } from "./TemplateLibrary";

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<"projects" | "ai" | "code" | "templates">("projects");
  const projects = useQuery(api.projects.getUserProjects) || [];
  const user = useQuery(api.auth.loggedInUser);

  const tabs = [
    { id: "projects", label: "Projects", icon: "📁", count: projects.length },
    { id: "ai", label: "AI Consultant", icon: "🤖", count: null },
    { id: "code", label: "Code Generator", icon: "💻", count: null },
    { id: "templates", label: "Templates", icon: "📋", count: null },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Welcome back, {user?.email?.split('@')[0] || 'Engineer'}! 👋
        </h2>
        <p className="text-gray-600">
          Ready to accelerate your engineering projects with AI assistance?
        </p>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-xl shadow-sm border">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
                {tab.count !== null && (
                  <span className="bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === "projects" && <ProjectManager />}
          {activeTab === "ai" && <AIConsultant />}
          {activeTab === "code" && <CodeGenerator />}
          {activeTab === "templates" && <TemplateLibrary />}
        </div>
      </div>
    </div>
  );
}
