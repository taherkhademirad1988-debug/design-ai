import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function TemplateLibrary() {
  const [activeTab, setActiveTab] = useState<"public" | "my">("public");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    name: "",
    description: "",
    category: "autocad_lisp" as const,
    code: "",
    language: "LISP",
    tags: "",
    isPublic: false,
  });

  const publicTemplates = useQuery(api.templates.getPublicTemplates, {
    category: selectedCategory as any || undefined,
  }) || [];
  const userTemplates = useQuery(api.templates.getUserTemplates) || [];
  const createTemplate = useMutation(api.templates.createTemplate);

  const categories = [
    { id: "", label: "All Categories", icon: "📋" },
    { id: "autocad_lisp", label: "AutoCAD LISP", icon: "📐" },
    { id: "solidworks_macro", label: "SolidWorks Macro", icon: "🔧" },
    { id: "blender_script", label: "Blender Script", icon: "🎨" },
    { id: "revit_family", label: "Revit Family", icon: "🏗️" },
    { id: "structural_calc", label: "Structural Calc", icon: "📊" },
  ];

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createTemplate({
        name: newTemplate.name,
        description: newTemplate.description,
        category: newTemplate.category,
        code: newTemplate.code,
        language: newTemplate.language,
        tags: newTemplate.tags.split(",").map(tag => tag.trim()).filter(Boolean),
        isPublic: newTemplate.isPublic,
      });
      setNewTemplate({
        name: "",
        description: "",
        category: "autocad_lisp",
        code: "",
        language: "LISP",
        tags: "",
        isPublic: false,
      });
      setShowCreateForm(false);
      toast.success("Template created successfully!");
    } catch (error) {
      toast.error("Failed to create template");
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("Code copied to clipboard!");
  };

  const templates = activeTab === "public" ? publicTemplates : userTemplates;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Code Template Library</h3>
        <button
          onClick={() => setShowCreateForm(true)}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
        >
          + Create Template
        </button>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
        <button
          onClick={() => setActiveTab("public")}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === "public"
              ? "bg-white text-gray-900 shadow-sm"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          Public Templates ({publicTemplates.length})
        </button>
        <button
          onClick={() => setActiveTab("my")}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
            activeTab === "my"
              ? "bg-white text-gray-900 shadow-sm"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          My Templates ({userTemplates.length})
        </button>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === cat.id
                ? "bg-blue-100 text-blue-800"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {cat.icon} {cat.label}
          </button>
        ))}
      </div>

      {/* Create Template Form */}
      {showCreateForm && (
        <div className="bg-gray-50 rounded-lg p-6 border">
          <h4 className="text-md font-semibold mb-4">Create New Template</h4>
          <form onSubmit={handleCreateTemplate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Template Name
                </label>
                <input
                  type="text"
                  value={newTemplate.name}
                  onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  value={newTemplate.category}
                  onChange={(e) => setNewTemplate({ ...newTemplate, category: e.target.value as any })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="autocad_lisp">AutoCAD LISP</option>
                  <option value="solidworks_macro">SolidWorks Macro</option>
                  <option value="blender_script">Blender Script</option>
                  <option value="revit_family">Revit Family</option>
                  <option value="structural_calc">Structural Calc</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                value={newTemplate.description}
                onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                rows={2}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Language
              </label>
              <input
                type="text"
                value={newTemplate.language}
                onChange={(e) => setNewTemplate({ ...newTemplate, language: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Code
              </label>
              <textarea
                value={newTemplate.code}
                onChange={(e) => setNewTemplate({ ...newTemplate, code: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-sm"
                rows={8}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tags (comma-separated)
              </label>
              <input
                type="text"
                value={newTemplate.tags}
                onChange={(e) => setNewTemplate({ ...newTemplate, tags: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="automation, drawing, utility"
              />
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="isPublic"
                checked={newTemplate.isPublic}
                onChange={(e) => setNewTemplate({ ...newTemplate, isPublic: e.target.checked })}
                className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
              />
              <label htmlFor="isPublic" className="ml-2 block text-sm text-gray-700">
                Make this template public
              </label>
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700"
              >
                Create Template
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Templates Grid */}
      {templates.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📋</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {activeTab === "public" ? "No public templates found" : "No templates yet"}
          </h3>
          <p className="text-gray-600 mb-4">
            {activeTab === "public" 
              ? "Try changing the category filter" 
              : "Create your first template to get started"
            }
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {templates.map((template) => (
            <div key={template._id} className="bg-white border rounded-lg p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">{template.name}</h4>
                  <p className="text-sm text-gray-600">{template.description}</p>
                </div>
                <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">
                  {template.language}
                </span>
              </div>

              <div className="bg-gray-900 rounded p-3 mb-4">
                <pre className="text-green-400 text-xs overflow-x-auto max-h-32">
                  <code>{template.code}</code>
                </pre>
              </div>

              {template.tags && template.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-4">
                  {template.tags.map((tag, index) => (
                    <span key={index} className="bg-blue-100 text-blue-600 px-2 py-1 rounded text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">
                  {template.category.replace('_', ' ')}
                </span>
                <button
                  onClick={() => copyCode(template.code)}
                  className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                >
                  Copy Code
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
