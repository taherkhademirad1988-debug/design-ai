import { useState } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function AIConsultant() {
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("cad_assistance");
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState("");

  const projects = useQuery(api.projects.getUserProjects) || [];
  const generateAdvice = useAction(api.ai.generateEngineeringAdvice);

  const categories = [
    { id: "cad_assistance", label: "CAD Assistance", icon: "📐", description: "AutoCAD, SolidWorks, Fusion 360 help" },
    { id: "3d_modeling", label: "3D Modeling", icon: "🎯", description: "Blender, Maya, 3ds Max guidance" },
    { id: "rendering_optimization", label: "Rendering", icon: "✨", description: "V-Ray, Arnold, Cycles optimization" },
    { id: "structural_analysis", label: "Structural Analysis", icon: "🏗️", description: "FEA, load analysis, building codes" },
    { id: "material_selection", label: "Material Selection", icon: "🔬", description: "Material properties and selection" },
    { id: "code_generation", label: "Code Generation", icon: "💻", description: "Scripts, macros, automation" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !query.trim()) {
      toast.error("Please select a project and enter your question");
      return;
    }

    setIsLoading(true);
    try {
      const result = await generateAdvice({
        projectId: selectedProject as any,
        query: query.trim(),
        category: category as any,
      });
      setResponse(result);
      toast.success("AI advice generated successfully!");
    } catch (error) {
      toast.error("Failed to generate AI advice");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Engineering Consultant</h3>
        <p className="text-gray-600">Get expert advice for your engineering challenges</p>
      </div>

      {/* Category Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Select Consultation Category
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id)}
              className={`p-4 rounded-lg border text-left transition-all ${
                category === cat.id
                  ? "border-blue-500 bg-blue-50 ring-2 ring-blue-200"
                  : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-lg">{cat.icon}</span>
                <span className="font-medium text-sm">{cat.label}</span>
              </div>
              <p className="text-xs text-gray-600">{cat.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Consultation Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Select Project
          </label>
          <select
            value={selectedProject}
            onChange={(e) => setSelectedProject(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          >
            <option value="">Choose a project...</option>
            {projects.map((project) => (
              <option key={project._id} value={project._id}>
                {project.name} ({project.type.replace('_', ' ')})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Your Question or Challenge
          </label>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={4}
            placeholder="Describe your engineering challenge, ask for specific guidance, or request code examples..."
            required
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !selectedProject || !query.trim()}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              <span>Generating AI Advice...</span>
            </>
          ) : (
            <>
              <span>🤖</span>
              <span>Get AI Advice</span>
            </>
          )}
        </button>
      </form>

      {/* Response Display */}
      {response && (
        <div className="bg-gray-50 rounded-lg p-6 border">
          <h4 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
            <span>🤖</span>
            <span>AI Engineering Advice</span>
          </h4>
          <div className="prose prose-sm max-w-none">
            <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans leading-relaxed">
              {response}
            </pre>
          </div>
        </div>
      )}

      {projects.length === 0 && (
        <div className="text-center py-8 bg-yellow-50 rounded-lg border border-yellow-200">
          <div className="text-4xl mb-2">📁</div>
          <h4 className="font-medium text-gray-900 mb-1">No Projects Found</h4>
          <p className="text-sm text-gray-600">Create a project first to get AI consultation</p>
        </div>
      )}
    </div>
  );
}
