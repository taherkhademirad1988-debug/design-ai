import { useState } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function CodeGenerator() {
  const [description, setDescription] = useState("");
  const [language, setLanguage] = useState("LISP");
  const [category, setCategory] = useState<string>("autocad_lisp");
  const [isLoading, setIsLoading] = useState(false);
  const [generatedCode, setGeneratedCode] = useState("");

  const generateCode = useAction(api.ai.generateCode);

  const categories = [
    { id: "autocad_lisp", label: "AutoCAD LISP", language: "LISP", icon: "📐" },
    { id: "solidworks_macro", label: "SolidWorks Macro", language: "VBA", icon: "🔧" },
    { id: "blender_script", label: "Blender Script", language: "Python", icon: "🎨" },
    { id: "revit_family", label: "Revit Family", language: "C#", icon: "🏗️" },
    { id: "structural_calc", label: "Structural Calc", language: "Python", icon: "📊" },
  ];

  const handleCategoryChange = (newCategory: string) => {
    setCategory(newCategory);
    const cat = categories.find(c => c.id === newCategory);
    if (cat) {
      setLanguage(cat.language);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      toast.error("Please describe what code you need");
      return;
    }

    setIsLoading(true);
    try {
      const result = await generateCode({
        language,
        description: description.trim(),
        category: category as any,
      });
      setGeneratedCode(result);
      toast.success("Code generated successfully!");
    } catch (error) {
      toast.error("Failed to generate code");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
    toast.success("Code copied to clipboard!");
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Code Generator</h3>
        <p className="text-gray-600">Generate scripts, macros, and automation code for engineering software</p>
      </div>

      {/* Category Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Select Code Type
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryChange(cat.id)}
              className={`p-4 rounded-lg border text-left transition-all ${
                category === cat.id
                  ? "border-blue-500 bg-blue-50 ring-2 ring-blue-200"
                  : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
              }`}
            >
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-lg">{cat.icon}</span>
                <span className="font-medium text-sm">{cat.label}</span>
              </div>
              <p className="text-xs text-gray-600">{cat.language}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Code Generation Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Language
          </label>
          <input
            type="text"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="e.g., LISP, Python, VBA, C#"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Code Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            rows={4}
            placeholder="Describe what you want the code to do. Be specific about functionality, inputs, outputs, and any special requirements..."
            required
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !description.trim()}
          className="w-full bg-green-600 text-white py-3 px-4 rounded-md hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              <span>Generating Code...</span>
            </>
          ) : (
            <>
              <span>💻</span>
              <span>Generate Code</span>
            </>
          )}
        </button>
      </form>

      {/* Generated Code Display */}
      {generatedCode && (
        <div className="bg-gray-900 rounded-lg p-6 border">
          <div className="flex justify-between items-center mb-4">
            <h4 className="font-semibold text-white flex items-center space-x-2">
              <span>💻</span>
              <span>Generated {language} Code</span>
            </h4>
            <button
              onClick={copyToClipboard}
              className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
            >
              Copy Code
            </button>
          </div>
          <pre className="text-green-400 text-sm overflow-x-auto">
            <code>{generatedCode}</code>
          </pre>
        </div>
      )}

      {/* Example Prompts */}
      <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
        <h4 className="font-semibold text-blue-900 mb-3">💡 Example Prompts</h4>
        <div className="space-y-2 text-sm">
          <div className="bg-white p-3 rounded border">
            <strong>AutoCAD LISP:</strong> "Create a function to automatically dimension all lines in a selection set"
          </div>
          <div className="bg-white p-3 rounded border">
            <strong>Blender Python:</strong> "Generate a script to create a parametric spiral staircase with adjustable steps"
          </div>
          <div className="bg-white p-3 rounded border">
            <strong>SolidWorks VBA:</strong> "Macro to export all parts in an assembly to STEP files with custom naming"
          </div>
        </div>
      </div>
    </div>
  );
}
