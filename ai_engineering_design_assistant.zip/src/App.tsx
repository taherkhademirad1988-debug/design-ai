import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Dashboard } from "./components/Dashboard";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-indigo-100">
      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur-sm border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AI</span>
            </div>
            <h1 className="text-xl font-bold text-gray-900">Engineering AI Assistant</h1>
          </div>
          <Authenticated>
            <SignOutButton />
          </Authenticated>
        </div>
      </header>

      <main className="flex-1">
        <Content />
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <Authenticated>
        <Dashboard />
      </Authenticated>
      
      <Unauthenticated>
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              AI-Powered Engineering Design
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Get intelligent assistance for CAD, 3D modeling, rendering, and structural engineering projects
            </p>
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-white p-4 rounded-lg shadow-sm border">
                <div className="text-blue-600 text-2xl mb-2">🏗️</div>
                <h3 className="font-semibold text-sm">CAD Assistance</h3>
                <p className="text-xs text-gray-600">AutoCAD, SolidWorks, Fusion 360</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm border">
                <div className="text-green-600 text-2xl mb-2">🎨</div>
                <h3 className="font-semibold text-sm">3D Modeling</h3>
                <p className="text-xs text-gray-600">Blender, Maya, 3ds Max</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm border">
                <div className="text-purple-600 text-2xl mb-2">✨</div>
                <h3 className="font-semibold text-sm">Rendering</h3>
                <p className="text-xs text-gray-600">V-Ray, Arnold, Cycles</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm border">
                <div className="text-orange-600 text-2xl mb-2">🔧</div>
                <h3 className="font-semibold text-sm">Structural Analysis</h3>
                <p className="text-xs text-gray-600">FEA, Load Analysis</p>
              </div>
            </div>
          </div>
          <SignInForm />
        </div>
      </Unauthenticated>
    </div>
  );
}
